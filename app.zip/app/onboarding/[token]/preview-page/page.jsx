import { useOnboardingStore } from "@/store/useOnboardingStore";
import { useNavigate } from "react-router-dom";

export default function PreviewPage() {
  const navigate = useNavigate();

  const {
    personal,
    address,
    education,
    experience,
  } = useOnboardingStore();

  return (
    <>
      <h2>Preview Your Details</h2>

      <section>
        <h3>Personal</h3>
        <p>{personal.firstName}</p>
        <button onClick={() => navigate("/onboarding/personal")}>Edit</button>
      </section>

      <section>
        <h3>Address</h3>
        <p>{address.city}</p>
        <button onClick={() => navigate("/onboarding/address")}>Edit</button>
      </section>

      <section>
        <h3>Education</h3>
        {education.map((e, i) => (
          <p key={i}>{e.degree}</p>
        ))}
      </section>

      <section>
        <h3>Experience</h3>
        {experience.map((e, i) => (
          <p key={i}>{e.company}</p>
        ))}
      </section>

      <button onClick={() => navigate("/onboarding/experience")}>Back</button>
      <button onClick={() => navigate("/onboarding/submit")}>Submit</button>
    </>
  );
}
